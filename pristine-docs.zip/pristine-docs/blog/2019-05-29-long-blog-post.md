---
title: Long Blog Post
description: How I set up blogs on my Docusaurus site.
slug: adding-blogs
date: 2023-09-23
authors:
  - name: Gamandeep Singh
    title: Developer & Blogger
    url: https://github.com/gamandeepsingh
    image_url: https://github.com/gamandeepsingh.png
tags: [blog, setup]
---

Adding blogs to my Docusaurus site was easy! Here’s how I did it...
