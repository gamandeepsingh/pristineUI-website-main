
import Link from '@docusaurus/Link';


export default function Home() {
  return (
    <div>
      <Link to="/docs/intro">Docs</Link>
    </div>  
  );
}
