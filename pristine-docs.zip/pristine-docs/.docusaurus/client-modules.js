export default [
  require("/home/ghost/Desktop/elanine/PRISTINE-WEBSITE/pristine-docs/node_modules/infima/dist/css/default/default.css"),
  require("/home/ghost/Desktop/elanine/PRISTINE-WEBSITE/pristine-docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/ghost/Desktop/elanine/PRISTINE-WEBSITE/pristine-docs/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/home/ghost/Desktop/elanine/PRISTINE-WEBSITE/pristine-docs/src/css/custom.css"),
];
