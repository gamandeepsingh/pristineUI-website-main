import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/blog',
    component: ComponentCreator('/blog', 'e1c'),
    exact: true
  },
  {
    path: '/blog/adding-blogs',
    component: ComponentCreator('/blog/adding-blogs', '8d5'),
    exact: true
  },
  {
    path: '/blog/adding-blogs',
    component: ComponentCreator('/blog/adding-blogs', '661'),
    exact: true
  },
  {
    path: '/blog/adding-blogs',
    component: ComponentCreator('/blog/adding-blogs', 'eb6'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '182'),
    exact: true
  },
  {
    path: '/blog/authors',
    component: ComponentCreator('/blog/authors', '0b7'),
    exact: true
  },
  {
    path: '/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/blog/authors/all-sebastien-lorber-articles', '0a8'),
    exact: true
  },
  {
    path: '/blog/authors/rohit',
    component: ComponentCreator('/blog/authors/rohit', '66a'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', '287'),
    exact: true
  },
  {
    path: '/blog/tags/blog',
    component: ComponentCreator('/blog/tags/blog', '3f5'),
    exact: true
  },
  {
    path: '/blog/tags/facebook',
    component: ComponentCreator('/blog/tags/facebook', '858'),
    exact: true
  },
  {
    path: '/blog/tags/linked-in',
    component: ComponentCreator('/blog/tags/linked-in', '8b7'),
    exact: true
  },
  {
    path: '/blog/tags/setup',
    component: ComponentCreator('/blog/tags/setup', '8b4'),
    exact: true
  },
  {
    path: '/blog/welcome',
    component: ComponentCreator('/blog/welcome', 'd2b'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '3d7'),
    exact: true
  },
  {
    path: '/search',
    component: ComponentCreator('/search', '822'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '600'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', '8dd'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', '810'),
            routes: [
              {
                path: '/docs/category/components',
                component: ComponentCreator('/docs/category/components', '84a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/category/getting-started',
                component: ComponentCreator('/docs/category/getting-started', '4e8'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Components/alert',
                component: ComponentCreator('/docs/Components/alert', '84c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Components/button',
                component: ComponentCreator('/docs/Components/button', '4fa'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Components/card',
                component: ComponentCreator('/docs/Components/card', 'ff1'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Components/Drawer',
                component: ComponentCreator('/docs/Components/Drawer', '737'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Components/DropDown',
                component: ComponentCreator('/docs/Components/DropDown', 'db2'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/congratulations',
                component: ComponentCreator('/docs/congratulations', '966'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/deploy-your-site',
                component: ComponentCreator('/docs/deploy-your-site', '976'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Getting Started/faq',
                component: ComponentCreator('/docs/Getting Started/faq', '738'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Getting Started/installation',
                component: ComponentCreator('/docs/Getting Started/installation', '4a1'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Getting Started/intro',
                component: ComponentCreator('/docs/Getting Started/intro', '477'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Getting Started/overview',
                component: ComponentCreator('/docs/Getting Started/overview', '988'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/Getting Started/usage',
                component: ComponentCreator('/docs/Getting Started/usage', 'd82'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', '2e1'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
